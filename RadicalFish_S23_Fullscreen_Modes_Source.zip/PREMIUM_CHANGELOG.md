# S23 Ultra premium source modifications

Implemented in source:
- Premium cyan/graphite interface colours, control translucency 20-100%.
- Movable/resizable pad, dynamic sticks, existing external controller auto-hide.
- Three separately saveable layout presets plus reset to defaults.
- Separate left/right stick sensitivity sliders 25-250% and deadzone sliders 0-35% (slider range supports 0-250, clamped to 35% in model).
- Persistent per-game settings using Android SharedPreferences.
- Immersive display cutout short-edge mode, Android fullscreen handling retained.
- Existing audio and graphics compatibility shims unchanged.

Not implemented: arbitrary button remapping; true swipe-to-aim independent of the existing stick; game-engine aspect ratio correction or verified graphics defect fix.
No local Android SDK build or device test performed. GitHub build required.
