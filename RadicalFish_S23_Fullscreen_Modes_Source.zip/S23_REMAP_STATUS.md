Button remapping API added to pad model and view. Not yet connected to an in-game selection menu or persistence. No FPS, rendering, shaders or audio changes. Build and device test required.
