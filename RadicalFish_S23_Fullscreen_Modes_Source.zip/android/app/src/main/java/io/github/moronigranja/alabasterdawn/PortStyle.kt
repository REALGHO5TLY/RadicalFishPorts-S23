package io.github.moronigranja.alabasterdawn

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList

/**
 * The port's own look, in one place: the console-style dark panel and warm off-white text the side
 * menu, the diagnostics dialog and the entry screen share.
 *
 * The palette is the port's own. No game art is drawn from here — each game card's art is
 * read out of the *user's* copy of the game at runtime (see [GameProfile.artPath] and `NOTICE.md`).
 */
object PortStyle {

    /** Body text and icons on the port's panels. */
    const val TEXT = 0xFFE7F3FA.toInt()

    /** Secondary text: status lines, folder names, section headers. */
    const val DIM = 0xB3E7F3FA.toInt()

    /** The panel's own colour; [SCRIM] is what dims the game behind the side menu. */
    const val PANEL = 0xF0101820.toInt()
    const val SCRIM = 0x99000000.toInt()

    /** The ripple and the filled pill that marks the current choice in a list. */
    const val RIPPLE = 0x3341D8F5
    const val PILL = 0x1F41D8F5

    /** The rounded square a game's title art sits in on its card (art with transparent corners
     *  still reads on it, and it is darker than the card so the tile has its own edge). */
    const val TILE = 0xFF0B1016.toInt()

    /** The hairline between rows. */
    const val HAIRLINE = 0x3341D8F5.toInt()

    /** A game that is ready to start (the status dot on the entry screen's rows). */
    const val ACCENT = 0xFF41D8F5.toInt()

    /** Text on an [ACCENT] fill. */
    const val INK = 0xFF0E1A22.toInt()

    fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    /** A rounded panel, the shape every screen of the port is built out of. */
    fun panel(context: Context, radiusDp: Int = 20, color: Int = PANEL): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(context, radiusDp).toFloat()
            setColor(color)
        }

    /**
     * A game card on the entry screen: the panel, outlined, so the rounded rectangle still reads
     * where the page behind it is the same near-black.
     */
    fun card(context: Context): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(context, 20).toFloat()
        setColor(PANEL)
        setStroke(dp(context, 1), HAIRLINE)
    }

    /** The rounded square a game's title art sits in on its card. */
    fun tile(context: Context): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(context, 14).toFloat()
        setColor(TILE)
    }

    /** The round play badge on a game card. */
    fun badge(context: Context): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(ACCENT)
    }

    /**
     * A row's background: a rounded ripple over the whole row, filled with a dim pill when the row is
     * the current choice. The mask has a colour on purpose — a mask is read by alpha, and an unfilled
     * GradientDrawable is transparent.
     */
    fun row(context: Context, filled: Boolean = false, radiusDp: Int = 24): RippleDrawable {
        val mask = GradientDrawable().apply {
            cornerRadius = dp(context, radiusDp).toFloat()
            setColor(android.graphics.Color.WHITE)
        }
        val content = if (filled) {
            GradientDrawable().apply {
                cornerRadius = dp(context, radiusDp).toFloat()
                setColor(PILL)
            }
        } else {
            null
        }
        return RippleDrawable(ColorStateList.valueOf(RIPPLE), content, mask)
    }

    /**
     * The port's button look. A platform `Button` is grey, all-caps and elevated, which reads as a
     * different app next to these panels; [primary] is the one filled action a screen has.
     */
    fun dress(button: Button, primary: Boolean = false) {
        val context = button.context
        button.background = if (primary) {
            GradientDrawable().apply {
                cornerRadius = dp(context, 12).toFloat()
                setColor(ACCENT)
            }
        } else {
            GradientDrawable().apply {
                cornerRadius = dp(context, 12).toFloat()
                setColor(android.graphics.Color.TRANSPARENT)
                setStroke(dp(context, 1), HAIRLINE)
            }
        }
        button.isAllCaps = false
        button.setTextColor(if (primary) INK else TEXT)
        button.textSize = 15f
        button.stateListAnimator = null
        button.minHeight = dp(context, 44)
    }

    /** The entry screen's little "this game is ready" dot. */
    fun dot(context: Context, ready: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (ready) ACCENT else RIPPLE)
    }
}
