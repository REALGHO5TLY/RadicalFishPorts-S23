# Remapping safety update
- Button remapping now swaps existing assignments instead of creating duplicate output mappings.
- Import/export methods support persistence, but no settings UI has been wired yet.
- Input releases before changing mappings, avoiding stuck outputs.
- FPS, audio, shaders and rendering code untouched.
- Source is not compiled or device-tested. GitHub is not updated by this archive.
